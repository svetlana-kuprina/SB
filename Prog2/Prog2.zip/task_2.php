<?php

$a=76;
$b=8;
var_dump($a%$b);