<?php

$a=5;
$b=5.6;
$d=11;

var_dump($a+$b<=$d);
