<?php

$a=2;
$b=3;

var_dump(++$a>=$b);