<?php

$arr = [
    'Москва' => 'Россия',
    'Мурманск' => 'Россия',
    'Рим' => 'Италия',
];
$arr_flip = array_flip($arr);
var_dump($arr_flip);
