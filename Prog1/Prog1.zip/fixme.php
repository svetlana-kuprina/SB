<?php

echo 'привет, мир';
