<?php

echo 'тевирП';
