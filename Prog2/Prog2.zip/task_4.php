<?php

$a=10;
$b=10;

var_dump($a!=$b--);